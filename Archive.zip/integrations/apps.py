from django.apps import AppConfig


class IntegrationsConfig(AppConfig):
    name = 'integrations'
